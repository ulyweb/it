#!/usr/bin/env python3
"""
MAC-MAINT v1.10 Server with BeyondTrust PRA Automation
Includes automatic detection and installation guidance for BeyondTrust
"""

import os
import sys
import json
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import urlparse
import threading

def _run(cmd):
    """Execute shell command"""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        return result.returncode == 0
    except:
        return False

class MainHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        
        if path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.end_headers()
            
            # Try to find HTML file by either name
            html_file = None
            if os.path.exists('dashboard_mac.html'):
                html_file = 'dashboard_mac.html'
            elif os.path.exists('dashboard_mac_with_beyondtrust.html'):
                html_file = 'dashboard_mac_with_beyondtrust.html'
            else:
                self.wfile.write(b'<h1>Dashboard file not found</h1>')
                return
            
            try:
                with open(html_file, 'r') as f:
                    self.wfile.write(f.read().encode('utf-8'))
            except Exception as e:
                self.wfile.write(f'<h1>Error loading dashboard: {e}</h1>'.encode('utf-8'))
        
        elif path == '/api/status':
            self.send_json({"status": "ok", "version": "1.10"})
        
        elif path == '/api/beyondtrust_status':
            self.check_beyondtrust()
        
        elif path == '/api/install_beyondtrust':
            self.trigger_beyondtrust_install()
        
        elif path == '/api/telemetry':
            self.get_telemetry()
        
        elif path == '/api/enterprise':
            self.get_enterprise_status()
        
        elif path == '/api/backup_status':
            self.get_backup_status()
        
        elif path == '/api/launch_selfservice':
            self.launch_selfservice()
        
        elif path == '/api/shutdown':
            self.send_json({"status": "shutdown"})
            os._exit(0)
        
        else:
            self.send_response(404)
            self.end_headers()
    
    def check_beyondtrust(self):
        """Check if BeyondTrust PRA is installed"""
        paths = [
            "/Applications/Jump Client.app",
            "/Applications/Open to Deploy Jump Client 3.app",
            "/Applications/Open to Deploy Jump Client.app",
        ]
        
        is_installed = False
        for p in paths:
            if os.path.isdir(p):
                is_installed = True
                break
        
        self.send_json({
            "beyondtrust_installed": is_installed,
            "status": "installed" if is_installed else "not_installed",
            "message": "✓ BeyondTrust PRA is ready" if is_installed else "⚠ BeyondTrust PRA not found"
        })
    
    def trigger_beyondtrust_install(self):
        """Guide user to install BeyondTrust via Self Service"""
        try:
            # Open Spotlight
            _run(["osascript", "-e", 'tell application "System Events" to key code 49 using {command down}'])
            
            self.send_json({
                "status": "opening_self_service",
                "message": "Self Service is opening. Search for 'BeyondTrust' or 'Jump' and click Install."
            })
        except Exception as e:
            self.send_json({"status": "error", "message": str(e)})
    
    def get_telemetry(self):
        """Get system telemetry"""
        self.send_json({
            "os": "macOS",
            "cpu": 0,
            "memory": 0,
            "disk": 0
        })
    
    def get_enterprise_status(self):
        """Get enterprise compliance status"""
        security_tools = {
            "Trellix Agent": ["masvc", "trellix", "mcafee"],
            "Digital Guardian": ["dgagent", "dgmd"],
            "GlobalProtect": ["PanGPS", "pangp"],
            "Jamf Connect": ["jamfconnect"],
            "Skyhigh Client": ["mcproxy", "skyhigh"],
            "CrowdStrike Falcon": ["falcond", "falcon"],
            "BeyondTrust PRA": ["Jump Client", "jumpclient"]
        }
        
        running = {}
        for tool, procs in security_tools.items():
            is_running = False
            for proc in procs:
                if _run(["pgrep", "-i", proc]):
                    is_running = True
                    break
            running[tool] = is_running
        
        self.send_json({"security_tools": running})
    
    def get_backup_status(self):
        """Get backup to Box status"""
        box_path = os.path.expanduser("~/Library/CloudStorage/Box-Box")
        backup_root = os.path.expanduser("~/Library/CloudStorage/Box-Box/01. My Personal Folder/recentBackup")
        
        last_backup = "Never"
        try:
            if os.path.isdir(backup_root):
                items = sorted(os.listdir(backup_root), reverse=True)
                backup_items = [f for f in items if f.startswith("Backup_")]
                if backup_items:
                    last_backup = backup_items[0].replace("Backup_", "").replace("_", " ")
        except:
            pass
        
        self.send_json({
            "box_installed": os.path.isdir(box_path),
            "last_backup": last_backup,
            "launcher_installed": True
        })
    
    def launch_selfservice(self):
        """Launch Self Service app"""
        try:
            _run(["open", "/Applications/Self Service.app"])
            self.send_json({"status": "launched"})
        except:
            self.send_json({"status": "not_found"})
    
    def send_json(self, data):
        """Send JSON response"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))
    
    def log_message(self, format, *args):
        """Suppress logging"""
        pass

class ThreadedServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

if __name__ == '__main__':
    port = 9292
    server = ThreadedServer(('localhost', port), MainHandler)
    print(f'MAC-MAINT v1.10 running on http://localhost:{port}')
    sys.stdout.flush()
    server.serve_forever()
