-- MAC-MAINT v1.10 - Enhanced Launcher with BeyondTrust PRA Automation
-- This properly finds and launches the shell script
-- Also detects and helps install BeyondTrust PRA if missing
--
-- SETUP:
-- 1. Export this as Application → MAC-MAINT.app
-- 2. Put in SAME folder with: mac-maint-launcher.sh
-- 3. Double-click MAC-MAINT.app to run!

on run
	try
		-- Get application bundle path
		set appPath to (path to me as text)
		
		-- Convert to POSIX path (removes colons, uses forward slashes)
		set appPOSIX to POSIX path of appPath
		
		-- Get directory by removing /Contents/MacOS/launcher from the path
		set appDir to do shell script "dirname " & quoted form of appPOSIX
		
		-- The launcher script
		set launcherScript to appDir & "/mac-maint-launcher.sh"
		
		-- Check if script exists
		set scriptCheck to do shell script "test -f " & quoted form of launcherScript & " && echo YES || echo NO"
		
		if scriptCheck is not "YES" then
			display alert "Error: Launcher Script Not Found" message "Could not find: mac-maint-launcher.sh

Location checked:
" & launcherScript & "

Please make sure mac-maint-launcher.sh is in the SAME FOLDER as MAC-MAINT.app" buttons {"OK"} as critical
			return
		end if
		
		-- Make sure it's executable
		do shell script "chmod +x " & quoted form of launcherScript
		
		-- CHECK FOR BEYONDTRUST PRA
		set beyondtrustCheck to checkBeyondTrustPRA()
		
		if beyondtrustCheck is false then
			-- BeyondTrust not installed - offer to help install
			set userChoice to display alert "BeyondTrust PRA Not Detected" message "BeyondTrust PRA (Privileged Remote Access) is not installed on this Mac.

This tool is required for IT remote support.

Would you like to install it now via Self Service?" buttons {"Skip for Now", "Install Now"} default button "Install Now"
			
			if button returned of userChoice is "Install Now" then
				-- Open Self Service and guide user
				installBeyondTrustPRA()
			end if
		else
			-- BeyondTrust is installed
			display notification "✓ BeyondTrust PRA is installed" with title "MAC-MAINT"
		end if
		
		-- Open Terminal and run the launcher script
		tell application "Terminal"
			activate
			do script "cd " & quoted form of appDir & " && bash " & quoted form of launcherScript
		end tell
		
	on error errMsg number errCode
		display alert "Error" message errMsg buttons {"OK"} as critical
	end try
end run

-- Function to check if BeyondTrust PRA is installed
on checkBeyondTrustPRA()
	try
		-- Check for common BeyondTrust PRA paths on macOS
		set pathsToCheck to {
			"/Applications/Jump Client.app",
			"/Applications/Open to Deploy Jump Client 3.app",
			"/Applications/Open to Deploy Jump Client.app"
		}
		
		repeat with testPath in pathsToCheck
			set pathExists to do shell script "test -d " & quoted form of testPath & " && echo YES || echo NO"
			if pathExists is "YES" then
				return true
			end if
		end repeat
		
		-- Also check using mdfind for Jump Client
		try
			set findResult to do shell script "mdfind -name 'Jump Client' 2>/dev/null | head -1"
			if findResult is not "" then
				return true
			end if
		end try
		
		return false
		
	on error
		return false
	end try
end checkBeyondTrustPRA

-- Function to guide user through BeyondTrust PRA installation
on installBeyondTrustPRA()
	try
		-- Open Self Service
		tell application "System Events"
			key code 49 using {command down}  -- Cmd+Space for Spotlight
		end tell
		
		delay 0.5
		
		-- Type "Self Service"
		tell application "System Events"
			keystroke "Self Service"
			delay 0.3
			key code 36  -- Return key
		end tell
		
		delay 2
		
		-- Show detailed instructions
		display alert "Self Service Instructions" message "Self Service has opened.

STEP 1: Search for 'BeyondTrust' or 'Jump'
STEP 2: Find 'Open to Deploy Jump Client 3' or similar
STEP 3: Click the 'Install' button
STEP 4: Wait for installation to complete (shows 'Done')
STEP 5: Self Service will show 'Reinstall' when done

After installation, MAC-MAINT will continue." buttons {"OK"} default button "OK"
		
		-- Wait for user to complete installation
		delay 15
		
		-- Check again if BeyondTrust is now installed
		set isNowInstalled to checkBeyondTrustPRA()
		
		if isNowInstalled then
			display alert "Installation Successful" message "✓ BeyondTrust PRA has been installed successfully!

Your system is now configured for IT remote support." buttons {"OK"} default button "OK"
		else
			display alert "Installation Pending" message "If you clicked 'Install' in Self Service, the installation may still be in progress.

You can restart MAC-MAINT after installation completes." buttons {"OK"} default button "OK"
		end if
		
	on error errMsg
		display alert "Error" message "Could not open Self Service. 

Please open Self Service manually and search for:
'Open to Deploy Jump Client 3' or 'BeyondTrust'

Then click Install." buttons {"OK"} as critical
	end try
end installBeyondTrustPRA
