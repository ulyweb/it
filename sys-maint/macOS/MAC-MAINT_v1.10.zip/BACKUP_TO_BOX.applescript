-- MAC-MAINT: Backup to Box Launcher
-- Executes the Backup_Your_Data_to_Box.scpt with proper error handling

property appName : "MAC-MAINT Backup to Box"
property appVersion : "1.0"

on run
	try
		-- Get the folder containing this script
		set scriptFolder to (path to me as text)
		set scriptFolder to text 1 thru ((offset of ":" in (reverse of (characters of scriptFolder as text)) as text) - 1) of scriptFolder
		
		-- Build path to the backup script
		set backupScriptPath to scriptFolder & "Backup_Your_Data_to_Box.scpt"
		
		-- Check if backup script exists
		tell application "System Events"
			if not (exists file backupScriptPath) then
				display alert "Backup Script Not Found" message "Could not find: Backup_Your_Data_to_Box.scpt in the same folder." as critical
				return
			end if
		end tell
		
		-- Run the backup script
		set backupScript to load script file backupScriptPath
		run backupScript
		
	on error errMsg number errCode
		display alert "Backup Error" message "An error occurred while running the backup:" & return & return & errMsg as critical
	end try
end run
