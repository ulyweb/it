#!/usr/bin/env python3
"""
MAC-MAINT v1.10 - Complete macOS Maintenance Server
Includes all endpoints: telemetry, enterprise, backup, beyondtrust
"""

import os
import sys
import json
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import urlparse
import threading
import re

def _run(cmd):
    """Execute shell command safely"""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, shell=isinstance(cmd, str), check=False)
        return result.stdout.strip()
    except:
        return ""

class MainHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        
        # Serve dashboard HTML
        if path == '/':
            try:
                # Try to find HTML file by either name
                html_file = None
                if os.path.exists('dashboard_mac.html'):
                    html_file = 'dashboard_mac.html'
                elif os.path.exists('dashboard_mac_with_beyondtrust.html'):
                    html_file = 'dashboard_mac_with_beyondtrust.html'
                elif os.path.exists('dashboard_mac_v1.10-COMPLETE.html'):
                    html_file = 'dashboard_mac_v1.10-COMPLETE.html'
                
                if html_file:
                    self.send_response(200)
                    self.send_header('Content-type', 'text/html; charset=utf-8')
                    self.end_headers()
                    with open(html_file, 'r') as f:
                        self.wfile.write(f.read().encode('utf-8'))
                else:
                    self.send_json({"error": "Dashboard not found"})
            except Exception as e:
                self.send_json({"error": str(e)})
        
        # API: Status
        elif path == '/api/status':
            self.send_json({"status": "ok", "version": "1.10", "platform": "macOS"})
        
        # API: Telemetry (live system info)
        elif path == '/api/telemetry':
            self.get_telemetry()
        
        # API: Enterprise compliance
        elif path == '/api/enterprise':
            self.get_enterprise()
        
        # API: BeyondTrust status
        elif path == '/api/beyondtrust_status':
            self.check_beyondtrust()
        
        # API: Launch BeyondTrust install
        elif path == '/api/install_beyondtrust':
            self.launch_beyondtrust_install()
        
        # API: Backup status
        elif path == '/api/backup_status':
            self.get_backup_status()
        
        # API: Launch backup
        elif path == '/api/launch_backup':
            self.launch_backup()
        
        # API: Launch Self Service
        elif path == '/api/launch_selfservice':
            self.launch_selfservice()
        
        # API: Shutdown
        elif path == '/api/shutdown':
            self.send_json({"status": "shutdown"})
            os._exit(0)
        
        else:
            self.send_response(404)
            self.end_headers()
    
    def get_telemetry(self):
        """Get live system telemetry"""
        try:
            # Get OS version
            os_version = _run("sw_vers -productVersion")
            
            # Get Model
            model = _run("system_profiler SPHardwareDataType | grep 'Model Identifier' | awk '{print $3}'")
            
            # Get Uptime
            uptime_raw = _run("uptime")
            uptime = uptime_raw.replace("up ", "").split(",")[0] if uptime_raw else "Unknown"
            
            # Get CPU usage
            cpu_str = _run("top -l 1 -n 0 | grep 'CPU usage'")
            cpu_match = re.search(r'(\d+\.\d+)%', cpu_str)
            cpu_percent = float(cpu_match.group(1)) if cpu_match else 0.0
            
            # Get Memory - use vm_stat
            vm_stat = _run("vm_stat | head -20")
            mem_percent = 0.0
            try:
                # Parse vm_stat output
                lines = vm_stat.split('\n')
                for line in lines:
                    if 'Pages active' in line:
                        active = int(line.split(':')[1].strip().split('.')[0])
                    if 'Pages wired' in line:
                        wired = int(line.split(':')[1].strip().split('.')[0])
                    if 'Pages compressed' in line:
                        compressed = int(line.split(':')[1].strip().split('.')[0])
                
                # Get total physical pages
                hw_memsize = int(_run("sysctl -n hw.memsize"))
                total_pages = hw_memsize // 4096  # Each page is 4096 bytes
                
                if total_pages > 0:
                    mem_percent = ((active + wired + compressed) / total_pages) * 100
                    mem_percent = min(100, max(0, mem_percent))
            except:
                mem_percent = 0.0
            
            # Get Disk usage
            disk_str = _run("df -h / | tail -1 | awk '{print $5}'")
            disk_match = re.search(r'(\d+)%', disk_str)
            disk_percent = float(disk_match.group(1)) if disk_match else 0.0
            
            # Get RAM
            ram_gb = _run("sysctl -n hw.memsize | awk '{print int($1 / 1024 / 1024 / 1024)}'")
            ram_display = f"{ram_gb} GB" if ram_gb else "Unknown"
            
            self.send_json({
                "os": f"macOS {os_version}",
                "model": model or "Unknown",
                "uptime": uptime or "Unknown",
                "cpu_percent": round(cpu_percent, 1),
                "mem_percent": round(mem_percent, 1),
                "disk_percent": round(disk_percent, 1),
                "ram": ram_display
            })
        except Exception as e:
            self.send_json({"error": str(e)})
    
    def get_enterprise(self):
        """Get enterprise compliance status"""
        try:
            security_tools = {
                "Trellix Agent": ["masvc", "trellix", "mcafee", "macmnsvc"],
                "Digital Guardian": ["dgagent", "dgmd"],
                "GlobalProtect": ["PanGPS", "pangp", "globalprotect"],
                "Jamf Connect": ["Jamf Connect", "jamfconnect"],
                "Skyhigh Client": ["mcproxy", "skyhigh", "scp"],
                "CrowdStrike Falcon": ["falcond", "falcon", "crowdstrike"],
                "BeyondTrust PRA": ["Jump Client", "jumpclient"]
            }
            
            running_tools = {}
            for tool, processes in security_tools.items():
                is_running = False
                for proc in processes:
                    result = _run(f"pgrep -i '{proc}'")
                    if result:
                        is_running = True
                        break
                running_tools[tool] = is_running
            
            self.send_json({"security_tools": running_tools})
        except Exception as e:
            self.send_json({"error": str(e)})
    
    def check_beyondtrust(self):
        """Check if BeyondTrust PRA is installed"""
        try:
            paths = [
                "/Applications/Jump Client.app",
                "/Applications/Open to Deploy Jump Client 3.app",
                "/Applications/Open to Deploy Jump Client.app",
            ]
            
            is_installed = False
            for p in paths:
                if os.path.isdir(p):
                    is_installed = True
                    break
            
            self.send_json({
                "beyondtrust_installed": is_installed,
                "status": "installed" if is_installed else "not_installed",
                "message": "✓ Installed and Ready" if is_installed else "⚠ Not Installed"
            })
        except Exception as e:
            self.send_json({"error": str(e)})
    
    def launch_beyondtrust_install(self):
        """Launch BeyondTrust installation via Self Service"""
        try:
            _run("osascript -e 'tell application \"System Events\" to key code 49 using {command down}'")
            self.send_json({"status": "opening_self_service"})
        except Exception as e:
            self.send_json({"status": "error", "message": str(e)})
    
    def get_backup_status(self):
        """Get backup to Box status"""
        try:
            box_path = os.path.expanduser("~/Library/CloudStorage/Box-Box")
            backup_root = os.path.expanduser("~/Library/CloudStorage/Box-Box/01. My Personal Folder/recentBackup")
            
            last_backup = "Never"
            try:
                if os.path.isdir(backup_root):
                    items = sorted(os.listdir(backup_root), reverse=True)
                    backup_items = [f for f in items if f.startswith("Backup_")]
                    if backup_items:
                        last_backup = backup_items[0].replace("Backup_", "").replace("_", " ")
            except:
                pass
            
            self.send_json({
                "box_installed": os.path.isdir(box_path),
                "backup_folder_exists": os.path.isdir(backup_root),
                "last_backup": last_backup
            })
        except Exception as e:
            self.send_json({"error": str(e)})
    
    def launch_backup(self):
        """Launch backup to Box"""
        try:
            self.send_json({"status": "not_implemented"})
        except Exception as e:
            self.send_json({"error": str(e)})
    
    def launch_selfservice(self):
        """Launch Self Service app"""
        try:
            _run("open /Applications/Self\\ Service.app")
            self.send_json({"status": "launched"})
        except:
            self.send_json({"status": "not_found"})
    
    def send_json(self, data):
        """Send JSON response"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))
    
    def log_message(self, format, *args):
        """Suppress logging"""
        pass

class ThreadedServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

if __name__ == '__main__':
    port = 9292
    server = ThreadedServer(('localhost', port), MainHandler)
    print(f'MAC-MAINT v1.10 running on http://localhost:{port}', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nShutdown requested', flush=True)
        sys.exit(0)
