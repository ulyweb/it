#!/bin/bash

# MAC-MAINT Backup to Box - One-Click Setup
# Just run this script, and everything is compiled and ready!

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PYTHON_SCRIPT="$SCRIPT_DIR/compile_backup_app.py"

echo ""
echo "╔════════════════════════════════════════════════════════╗"
echo "║  MAC-MAINT Backup to Box - Auto Compiler Setup        ║"
echo "║  Just sit back, this will be done in seconds!          ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Check if Python script exists
if [ ! -f "$PYTHON_SCRIPT" ]; then
    echo "❌ ERROR: compile_backup_app.py not found!"
    echo "   Expected: $PYTHON_SCRIPT"
    exit 1
fi

# Make it executable
chmod +x "$PYTHON_SCRIPT"

# Run the Python compiler
python3 "$PYTHON_SCRIPT"

RESULT=$?

if [ $RESULT -eq 0 ]; then
    echo ""
    echo "✅ Setup complete! You can close this window."
    echo ""
    sleep 2
else
    echo ""
    echo "❌ Setup failed. Check the errors above."
    echo ""
    sleep 5
fi

exit $RESULT
