#!/usr/bin/env python3
"""
MAC-MAINT Backup to Box - Auto Compiler
Converts BACKUP_TO_BOX_STANDALONE.applescript to a ready-to-use .app bundle
Run this once on your Mac, and it's done!
"""

import os
import sys
import subprocess
import shutil
import json
from pathlib import Path

def main():
    print("=" * 70)
    print("MAC-MAINT Backup to Box - Automatic Compiler v1.0")
    print("=" * 70)
    print()
    
    # Define paths
    script_dir = Path(__file__).parent
    source_script = script_dir / "BACKUP_TO_BOX_STANDALONE.applescript"
    app_name = "BACKUP_TO_BOX.app"
    app_path = Path("/Applications/MAC-MAINT") / app_name
    
    print(f"📁 Source: {source_script}")
    print(f"🎯 Destination: {app_path}")
    print()
    
    # Check if source exists
    if not source_script.exists():
        print("❌ ERROR: BACKUP_TO_BOX_STANDALONE.applescript not found!")
        print(f"   Expected at: {source_script}")
        return False
    
    print("✓ Source script found")
    
    # Create /Applications/MAC-MAINT directory if needed
    mac_maint_dir = Path("/Applications/MAC-MAINT")
    if not mac_maint_dir.exists():
        print(f"📁 Creating {mac_maint_dir}...")
        try:
            mac_maint_dir.mkdir(parents=True, exist_ok=True)
        except PermissionError:
            print("⚠️  Need admin privileges to create /Applications/MAC-MAINT")
            print("   Running with sudo...")
            try:
                subprocess.run(["sudo", "mkdir", "-p", str(mac_maint_dir)], check=True)
            except subprocess.CalledProcessError:
                print("❌ Failed to create directory")
                return False
    
    print("✓ /Applications/MAC-MAINT directory ready")
    
    # Compile AppleScript to .app using osacompile
    print()
    print("🔧 Compiling AppleScript to .app bundle...")
    
    try:
        cmd = [
            "osacompile",
            "-l", "AppleScript",
            "-o", str(app_path),
            str(source_script)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        
        if result.returncode == 0:
            print(f"✓ Successfully compiled to {app_name}")
        else:
            print(f"❌ Compilation failed: {result.stderr}")
            return False
            
    except FileNotFoundError:
        print("❌ ERROR: 'osacompile' not found (AppleScript compiler)")
        print("   This should be built-in on macOS. Check your system.")
        return False
    except subprocess.CalledProcessError as e:
        print(f"❌ Compilation error: {e.stderr}")
        return False
    
    # Verify the app was created
    if not app_path.exists():
        print(f"❌ App bundle not found at {app_path}")
        return False
    
    print()
    print("=" * 70)
    print("✅ SUCCESS!")
    print("=" * 70)
    print()
    print(f"🎉 Backup app is ready at:")
    print(f"   {app_path}")
    print()
    print("📋 NEXT STEPS:")
    print("   1. The app is already installed!")
    print("   2. Open MAC-MAINT v1.9")
    print("   3. Click '🏢 Enterprise' tab")
    print("   4. Click '🚀 Backup Now' button")
    print()
    print("🔐 The backup script will:")
    print("   ✓ Show permission check dialog")
    print("   ✓ Let you select multiple folders (⌘+click)")
    print("   ✓ Confirm count before backup")
    print("   ✓ Create timestamped folder in Box")
    print("   ✓ ZIP each folder automatically")
    print("   ✓ Save log to Desktop")
    print()
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
