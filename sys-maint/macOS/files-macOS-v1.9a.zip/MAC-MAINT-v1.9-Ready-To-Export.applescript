-- MAC-MAINT v1.9 - macOS Maintenance Console
-- Complete AppleScript Launcher
-- 
-- HOW TO USE:
-- 1. Open this file in Script Editor (Applications → Utilities)
-- 2. Click "Compile" (hammer icon) - should show no errors
-- 3. File → Export → Format: Application → Save as "MAC-MAINT"
-- 4. Done! You have MAC-MAINT.app
--
-- REQUIREMENTS:
-- - Same folder must contain: launcher_mac.py and dashboard_mac.html
-- - Python 3 installed on Mac
-- - Internet browser (Safari, Chrome, Firefox)

on run
	try
		-- ══════════════════════════════════════════════════════════════
		-- SETUP: Get script location and define paths
		-- ══════════════════════════════════════════════════════════════
		
		set appName to "MAC-MAINT v1.9"
		set appPort to 9292
		
		-- Get the folder containing this script
		set scriptPath to (path to me as text)
		set scriptFolder to text 1 thru ((length of scriptPath) - (length of (reverse of (characters of scriptPath as text))) - 1) of scriptPath
		set scriptFolder to POSIX path of scriptFolder
		
		-- Define file paths
		set pyServer to scriptFolder & "launcher_mac.py"
		set htmlDash to scriptFolder & "dashboard_mac.html"
		set logFile to "/tmp/mac-maint.log"
		
		-- ══════════════════════════════════════════════════════════════
		-- CHECK: Python 3 exists
		-- ══════════════════════════════════════════════════════════════
		
		try
			set pythonCheck to do shell script "which python3"
			set pythonPath to pythonCheck
		on error
			display alert "Python 3 Not Found" message "MAC-MAINT requires Python 3.

Install from: https://www.python.org/downloads/macos/

Or use Homebrew:
  brew install python3" buttons {"OK"} as critical
			return
		end try
		
		-- ══════════════════════════════════════════════════════════════
		-- CHECK: Server file exists
		-- ══════════════════════════════════════════════════════════════
		
		set serverExists to do shell script "[ -f " & quoted form of pyServer & " ] && echo true || echo false"
		
		if serverExists is not "true" then
			display alert "Server File Missing" message "Could not find: launcher_mac.py

Expected location:
" & pyServer & "

Make sure launcher_mac.py is in the SAME folder as MAC-MAINT.app" buttons {"OK"} as critical
			return
		end if
		
		-- ══════════════════════════════════════════════════════════════
		-- CHECK: Dashboard file exists
		-- ══════════════════════════════════════════════════════════════
		
		set dashExists to do shell script "[ -f " & quoted form of htmlDash & " ] && echo true || echo false"
		
		if dashExists is not "true" then
			display alert "Dashboard File Missing" message "Could not find: dashboard_mac.html

Expected location:
" & htmlDash & "

Make sure dashboard_mac.html is in the SAME folder as MAC-MAINT.app" buttons {"OK"} as critical
			return
		end if
		
		-- ══════════════════════════════════════════════════════════════
		-- CLEANUP: Kill any existing process on port 9292
		-- ══════════════════════════════════════════════════════════════
		
		try
			do shell script "lsof -ti tcp:" & appPort & " | xargs kill -9 2>/dev/null || true"
			delay 1
		on error
			-- Port was already free
		end try
		
		-- ══════════════════════════════════════════════════════════════
		-- START: Launch Python server
		-- ══════════════════════════════════════════════════════════════
		
		set launchCmd to "cd " & quoted form of scriptFolder & " && nohup python3 " & quoted form of pyServer & " > " & quoted form of logFile & " 2>&1 &"
		
		do shell script launchCmd
		
		-- ══════════════════════════════════════════════════════════════
		-- WAIT: Give server time to start
		-- ══════════════════════════════════════════════════════════════
		
		delay 3
		
		-- ══════════════════════════════════════════════════════════════
		-- VERIFY: Server is running
		-- ══════════════════════════════════════════════════════════════
		
		try
			set portCheck to do shell script "lsof -ti tcp:" & appPort & " | head -1"
			if portCheck is "" then
				set logOutput to do shell script "cat " & quoted form of logFile
				display alert "Server Failed to Start" message "MAC-MAINT server could not start.

Check log file for details:
" & logFile & "

Log output:
" & logOutput buttons {"OK"} as critical
				return
			end if
		on error
			display alert "Server Check Failed" message "Could not verify if server is running.

Try running again, or check:
" & logFile buttons {"OK"} as critical
			return
		end try
		
		-- ══════════════════════════════════════════════════════════════
		-- OPEN: Browser to localhost:9292
		-- ══════════════════════════════════════════════════════════════
		
		delay 1
		open location "http://localhost:" & appPort
		
		-- ══════════════════════════════════════════════════════════════
		-- SUCCESS: Show notification
		-- ══════════════════════════════════════════════════════════════
		
		display notification appName & " is running on localhost:" & appPort with title "✓ MAC-MAINT Started"
		
		-- ══════════════════════════════════════════════════════════════
		-- SUCCESS DIALOG
		-- ══════════════════════════════════════════════════════════════
		
		display alert appName & " is Running" message "✅ MAC-MAINT v1.9 has started successfully!

Your browser is opening the dashboard.

If the browser doesn't appear automatically:
  → Go to: http://localhost:" & appPort & "

Dashboard Features:
  📟 Terminal - Command output
  📋 Processes - System processes
  🏢 Enterprise - Compliance & Backup

To stop MAC-MAINT:
  → Quit this application or run:
  → kill $(lsof -ti tcp:" & appPort & ")" buttons {"OK"} default button "OK"
		
	on error errMsg number errCode
		display alert "MAC-MAINT Error" message "An error occurred:

" & errMsg & " (Error " & errCode & ")" buttons {"OK"} as critical
	end try
end run
