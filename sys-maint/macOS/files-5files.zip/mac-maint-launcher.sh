#!/bin/bash

###############################################################################
#                                                                             #
#  MAC-MAINT v1.9 - macOS Maintenance Console                               #
#  Simple Launcher Script - Just Run This!                                  #
#                                                                             #
###############################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                                                            ║${NC}"
echo -e "${BLUE}║           MAC-MAINT v1.9 - Maintenance Console            ║${NC}"
echo -e "${BLUE}║                                                            ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Define file paths
PY_SERVER="$SCRIPT_DIR/launcher_mac.py"
HTML_DASH="$SCRIPT_DIR/dashboard_mac.html"
PORT=9292
LOG_FILE="/tmp/mac-maint.log"

echo -e "${BLUE}Checking requirements...${NC}"
echo ""

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ ERROR: Python 3 is not installed${NC}"
    echo ""
    echo "Python 3 is required to run MAC-MAINT"
    echo "Install from: https://www.python.org/downloads/macos/"
    echo ""
    echo "Or use Homebrew: brew install python3"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo -e "${GREEN}✓ Python 3 found${NC} (version $PYTHON_VERSION)"

# Check if server file exists
if [ ! -f "$PY_SERVER" ]; then
    echo -e "${RED}❌ ERROR: launcher_mac.py not found${NC}"
    echo "   Expected at: $PY_SERVER"
    echo ""
    echo "Make sure all files are in the same folder:"
    echo "  • launcher_mac.py"
    echo "  • dashboard_mac.html"
    echo "  • mac-maint-launcher.sh (this file)"
    exit 1
fi

echo -e "${GREEN}✓ Server script found${NC}"

# Check if dashboard file exists
if [ ! -f "$HTML_DASH" ]; then
    echo -e "${RED}❌ ERROR: dashboard_mac.html not found${NC}"
    echo "   Expected at: $HTML_DASH"
    exit 1
fi

echo -e "${GREEN}✓ Dashboard found${NC}"
echo ""

# Kill any existing process on the port
echo -e "${BLUE}Cleaning up old processes...${NC}"
if lsof -ti tcp:$PORT 2>/dev/null | xargs kill -9 2>/dev/null; then
    echo -e "${GREEN}✓ Cleaned up port $PORT${NC}"
    sleep 1
else
    echo -e "${GREEN}✓ Port $PORT is free${NC}"
fi

echo ""
echo -e "${BLUE}Starting MAC-MAINT server...${NC}"

# Start the Python server in the background
cd "$SCRIPT_DIR"
nohup python3 "$PY_SERVER" > "$LOG_FILE" 2>&1 &
SERVER_PID=$!

echo -e "${GREEN}✓ Server started (PID: $SERVER_PID)${NC}"

# Wait for server to fully start
echo -e "${YELLOW}⏳ Waiting for server to initialize...${NC}"
sleep 3

# Check if server is still running
if ! kill -0 $SERVER_PID 2>/dev/null; then
    echo -e "${RED}❌ Server failed to start!${NC}"
    echo ""
    echo "Check the log file for details:"
    echo "  $LOG_FILE"
    echo ""
    echo "Log contents:"
    cat "$LOG_FILE"
    exit 1
fi

echo -e "${GREEN}✓ Server is running${NC}"
echo ""

# Open the browser
echo -e "${BLUE}Opening dashboard in your browser...${NC}"
sleep 1
open "http://localhost:$PORT"

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                            ║${NC}"
echo -e "${GREEN}║              ✅ MAC-MAINT IS RUNNING!                     ║${NC}"
echo -e "${GREEN}║                                                            ║${NC}"
echo -e "${GREEN}║  Dashboard: http://localhost:$PORT                        ║${NC}"
echo -e "${GREEN}║  Process ID: $SERVER_PID                                       ║${NC}"
echo -e "${GREEN}║                                                            ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${YELLOW}📝 To stop MAC-MAINT:${NC}"
echo "   kill $SERVER_PID"
echo "   OR press Ctrl+C in Terminal"
echo ""

echo -e "${YELLOW}📋 Server log:${NC}"
echo "   $LOG_FILE"
echo ""

echo -e "${YELLOW}✨ Dashboard is loading...${NC}"
echo "   If the browser doesn't open, go to: http://localhost:$PORT"
echo ""

# Keep the script running (user can Ctrl+C to stop)
wait $SERVER_PID
