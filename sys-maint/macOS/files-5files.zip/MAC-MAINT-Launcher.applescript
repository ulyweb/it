-- MAC-MAINT v1.9 - Launcher AppleScript
-- This launches the actual working shell script
-- 
-- SETUP INSTRUCTIONS:
-- 1. Save this as MAC-MAINT-Launcher.applescript
-- 2. Export as Application → MAC-MAINT.app
-- 3. Put in same folder with: mac-maint-launcher.sh
-- 4. Double-click MAC-MAINT.app to run!

on run
	try
		-- Get the script directory
		set scriptPath to (path to me as text)
		set scriptFolder to text 1 thru ((length of scriptPath) - (length of (reverse of (characters of scriptPath as text))) - 1) of scriptPath
		set scriptFolder to POSIX path of scriptFolder
		
		-- The shell script that actually runs everything
		set launcherScript to scriptFolder & "mac-maint-launcher.sh"
		
		-- Check if launcher script exists
		set scriptExists to do shell script "[ -f " & quoted form of launcherScript & " ] && echo true || echo false"
		
		if scriptExists is not "true" then
			display alert "Launcher Script Not Found" message "Could not find: mac-maint-launcher.sh

Expected location:
" & launcherScript & "

Make sure mac-maint-launcher.sh is in the SAME folder as MAC-MAINT.app" buttons {"OK"} as critical
			return
		end if
		
		-- Launch the shell script in Terminal
		-- This opens it in a Terminal window so you can see output
		tell application "Terminal"
			activate
			do script "bash " & quoted form of launcherScript
		end tell
		
	on error errMsg number errCode
		display alert "Error" message errMsg buttons {"OK"} as critical
	end try
end run
