# 🔐 MAC-MAINT Backup to Box - Complete Setup Guide

## ⚡ ONE-CLICK SETUP (Recommended)

### On Your Mac:

1. **Download these files to the same folder:**
   - `BACKUP_TO_BOX_STANDALONE.applescript` (the backup script)
   - `compile_backup_app.py` (the compiler)
   - `SETUP_BACKUP.sh` (the launcher)

2. **Double-click `SETUP_BACKUP.sh`**
   - A Terminal window opens
   - Script compiles automatically
   - Done! ✅

---

## 📋 What Happens Automatically

The setup script will:
- ✅ Compile `BACKUP_TO_BOX_STANDALONE.applescript` to a macOS .app bundle
- ✅ Create `/Applications/MAC-MAINT/` directory (with permissions as needed)
- ✅ Install `BACKUP_TO_BOX.app` ready to use
- ✅ Verify everything worked

---

## 🚀 Using Backup to Box in MAC-MAINT

### After Setup:

1. **Open MAC-MAINT v1.9**
   - Launch the dashboard (localhost:9292)

2. **Click the `🏢 Enterprise` tab**

3. **You'll see the Backup Card:**
   ```
   🔐 Backup Your Data to Box
   Select multiple folders and back them up to Box with automatic ZIP compression
   
   Last backup: [DATE/TIME]
   
   [🔄 Check Status] [🚀 Backup Now]
   ```

4. **Click `🚀 Backup Now`**
   - File picker opens automatically
   - Select folders (hold ⌘ to select multiple)
   - Click "Open"
   - Confirm backup count
   - Watch progress
   - Success message with log location

---

## 📝 What the Backup Script Does

### Step-by-Step:

1. **Permissions Check**
   - Verifies you have Files & Folders access
   - Verifies Accessibility control is allowed
   - Shows you what to do if permissions missing

2. **Folder Selection**
   - Native macOS file picker
   - Select any folders you want to backup
   - Hold ⌘ (Command) to select multiple

3. **Confirmation**
   - Shows count: "You selected 3 folder(s) to back up"
   - You confirm: "Yes" or "Cancel"

4. **Creates Backup Directory**
   - Timestamped folder: `Backup_2024-01-15_143210`
   - Located in: `~/Library/CloudStorage/Box-Box/01. My Personal Folder/recentBackup/`

5. **ZIP Compression**
   - Each folder becomes: `FolderName.zip`
   - Progress shows in Dock
   - Each zip logs to Desktop

6. **Final Log**
   - `BoxBackupLog_YYYYMMDDhhmmss.txt` on Desktop
   - Shows what was zipped and where
   - Timestamp of completion

---

## 🛠️ Manual Compilation (If Needed)

If automatic setup doesn't work:

### Using Script Editor (macOS native):

1. **Open Script Editor** (Applications → Utilities)

2. **Open the file:**
   - File → Open
   - Select: `BACKUP_TO_BOX_STANDALONE.applescript`

3. **Compile:**
   - Click "Compile" button (hammer icon)
   - Should show green with no errors

4. **Export as App:**
   - File → Export
   - File Format: **Application** (not Script)
   - Name: `BACKUP_TO_BOX`
   - Location: **Create this folder first:**
     ```bash
     mkdir -p /Applications/MAC-MAINT
     ```
   - Save location: `/Applications/MAC-MAINT/`

5. **Done!** Now use it in MAC-MAINT Enterprise tab.

---

## ✅ Testing the Setup

1. Open MAC-MAINT
2. Go to **🏢 Enterprise** tab
3. Click **🔄 Check Status**
   - Should show: "Last backup: Never" (first time)
   - Or: "Last backup: [DATE]" (if you've backed up before)

4. Click **🚀 Backup Now**
   - File picker should open
   - If it does: ✅ Everything works!

---

## ⚠️ Troubleshooting

### "Backup Now button is grayed out"
- **Reason:** Box sync not detected
- **Fix:** Install Box or enable Box Sync
- **Check:** Is folder `~/Library/CloudStorage/Box-Box/` present?

### "File picker doesn't open"
- **Reason:** Script Editor isn't granted Accessibility control
- **Fix:** System Settings → Privacy & Security → Accessibility
  - Add "Script Editor" to allowed apps

### "Zipping fails silently"
- **Reason:** Missing Files & Folders permission
- **Fix:** System Settings → Privacy & Security → Files and Folders
  - Make sure Script Editor has access to your folders

### "Box backup folder doesn't exist"
- **Reason:** Wrong path or Box not configured
- **Check:** Does this folder exist?
  ```
  ~/Library/CloudStorage/Box-Box/01. My Personal Folder/recentBackup/
  ```
- **If not:** Create it manually or change path in script

---

## 📦 Files Included

```
WinMaintenance/
├── BACKUP_TO_BOX_STANDALONE.applescript   ← The backup script (all-in-one)
├── compile_backup_app.py                  ← Python compiler
├── SETUP_BACKUP.sh                        ← One-click setup launcher
├── README_BACKUP.md                       ← This file
│
├── launcher_mac.py                        ← MAC-MAINT server (updated)
├── dashboard_mac.html                     ← MAC-MAINT dashboard (updated)
│
└── [other files...]
```

---

## 🔐 Security Notes

- ✅ Script runs locally on your Mac only
- ✅ No cloud storage during backup (files → Box via Sync)
- ✅ Logs saved to Desktop (you can review them)
- ✅ No external dependencies beyond macOS built-ins
- ✅ Script source is readable (you can audit it)

---

## 📞 Support

If setup fails:
1. Check error messages carefully
2. Verify permissions in System Settings
3. Ensure Box Sync is installed
4. Check that `/Applications/MAC-MAINT/` was created

---

**Version:** MAC-MAINT v1.9 with Backup Integration  
**Status:** Production Ready ✅
