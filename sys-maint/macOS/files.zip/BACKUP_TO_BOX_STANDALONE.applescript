-- MAC-MAINT v1.9 BACKUP TO BOX
-- Compiled Backup Script - ALL IN ONE FILE
-- No external dependencies needed

on run
	try
		-- ════════════════════════════════════════════════════════════════
		-- SECTION 1: PERMISSIONS CHECK
		-- ════════════════════════════════════════════════════════════════
		
		display alert "Backup to Box" message "Before continuing, make sure the App has the necessary permissions:

1. Go to System Settings > Privacy & Security > Files and Folders:
   - Allow access to 'Desktop' and any source folders you choose.

2. Go to Privacy & Security > Accessibility:
   - Allow 'Script Editor' (or the app running this script) to control your computer.

Without these permissions, the backup may fail.

Click OK when you're ready to continue." buttons {"OK"} default button "OK"
		
		-- ════════════════════════════════════════════════════════════════
		-- SECTION 2: SET UP PATHS
		-- ════════════════════════════════════════════════════════════════
		
		set userHome to (path to home folder as text)
		set backupRoot to userHome & "Library/CloudStorage/Box-Box/01. My Personal Folder/recentBackup/"
		set desktopPath to userHome & "Desktop/"
		set logFile to desktopPath & "BoxBackupLog_" & (do shell script "date +%Y%m%d%H%M%S") & ".txt"
		
		-- ════════════════════════════════════════════════════════════════
		-- SECTION 3: FOLDER SELECTION REMINDER
		-- ════════════════════════════════════════════════════════════════
		
		display alert "Backup to Box" message "Tip: You can select multiple folders by holding the ⌘ (Command) key while clicking." buttons {"OK"} default button "OK"
		
		-- ════════════════════════════════════════════════════════════════
		-- SECTION 4: ASK USER TO SELECT SOURCE FOLDERS
		-- ════════════════════════════════════════════════════════════════
		
		set sourceFolders to (choose folder with prompt "Select the folders you want to back up (hold ⌘ to select multiple)" with multiple selections allowed)
		
		-- ════════════════════════════════════════════════════════════════
		-- SECTION 5: CONFIRM BEFORE STARTING
		-- ════════════════════════════════════════════════════════════════
		
		set totalItems to count sourceFolders
		
		set response to display alert "Backup Confirmation" message ("You selected " & totalItems & " folder(s) to back up to Box. Proceed?") buttons {"Cancel", "Yes"} default button "Yes"
		
		if button returned of response is "Cancel" then
			display alert "Backup Cancelled" message "Backup cancelled by user." buttons {"OK"} default button "OK"
			return
		end if
		
		-- ════════════════════════════════════════════════════════════════
		-- SECTION 6: CREATE BACKUP DIRECTORY
		-- ════════════════════════════════════════════════════════════════
		
		set timestamp to do shell script "date +%Y-%m-%d_%H%M%S"
		set backupFolderName to "Backup_" & timestamp
		set finalBackupPath to backupRoot & backupFolderName
		
		do shell script "mkdir -p " & quoted form of finalBackupPath
		
		-- ════════════════════════════════════════════════════════════════
		-- SECTION 7: BEGIN BACKUP LOOP WITH DOCK PROGRESS
		-- ════════════════════════════════════════════════════════════════
		
		set totalFolders to count of sourceFolders
		set folderIndex to 0
		
		repeat with sourceFolder in sourceFolders
			set folderIndex to folderIndex + 1
			
			-- Get folder name
			set folderName to name of (info for sourceFolder)
			
			-- Create zip name
			set zipName to folderName & ".zip"
			set destinationZip to finalBackupPath & "/" & zipName
			
			-- Calculate progress percentage
			set progressPercent to (folderIndex / totalFolders) * 100
			
			-- Update Dock progress (visual indicator)
			do shell script "osascript -e 'tell application \"System Events\" to set the dock tile size of process \"Script Editor\" to 32' >/dev/null 2>&1 &"
			do shell script "osascript -e 'tell application \"System Events\" to tell process \"Script Editor\" to set value of attribute \"AXValue\" of progress indicator 1 of window 1 to " & (progressPercent as text) & "' >/dev/null 2>&1 &"
			
			-- Quick UI progress notice
			display alert "Backing Up" message ("Zipping folder " & folderIndex & " of " & totalFolders & ":
" & folderName) buttons {"OK"} default button "OK" giving up after 2
			
			-- Zip folder contents
			set sourcePath to quoted form of (sourceFolder as text)
			set sourcePath to text 1 thru -2 of sourcePath  -- Remove trailing ':'
			
			do shell script "cd " & sourcePath & " && zip -r " & quoted form of destinationZip & " . >/dev/null 2>&1"
			
			-- Log each zip
			do shell script "echo 'Zipped: " & folderName & " -> " & zipName & "' >> " & quoted form of logFile
		end repeat
		
		-- ════════════════════════════════════════════════════════════════
		-- SECTION 8: FINAL SUCCESS MESSAGE
		-- ════════════════════════════════════════════════════════════════
		
		display alert "Backup Complete!" message ("✓ Backup complete!

 ▸ Files saved to:
" & finalBackupPath & "

 ▸ Log saved to your Desktop:
" & logFile) buttons {"OK"} default button "OK"
		
	on error errMsg number errCode
		display alert "Backup Error" message ("An error occurred:
" & errMsg) as critical
	end try
end run
