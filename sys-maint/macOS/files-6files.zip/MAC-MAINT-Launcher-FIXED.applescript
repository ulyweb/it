-- MAC-MAINT v1.9 - Fixed Launcher AppleScript
-- This properly finds and launches the shell script
--
-- SETUP:
-- 1. Export this as Application → MAC-MAINT.app
-- 2. Put in SAME folder with: mac-maint-launcher.sh
-- 3. Double-click MAC-MAINT.app to run!

on run
	try
		-- Get application bundle path
		set appPath to (path to me as text)
		
		-- Convert to POSIX path (removes colons, uses forward slashes)
		set appPOSIX to POSIX path of appPath
		
		-- Get directory by removing /Contents/MacOS/launcher from the path
		set appDir to do shell script "dirname " & quoted form of appPOSIX
		
		-- The launcher script
		set launcherScript to appDir & "/mac-maint-launcher.sh"
		
		-- Check if script exists
		set scriptCheck to do shell script "test -f " & quoted form of launcherScript & " && echo YES || echo NO"
		
		if scriptCheck is not "YES" then
			display alert "Error: Launcher Script Not Found" message "Could not find: mac-maint-launcher.sh

Location checked:
" & launcherScript & "

Please make sure mac-maint-launcher.sh is in the SAME FOLDER as MAC-MAINT.app" buttons {"OK"} as critical
			return
		end if
		
		-- Make sure it's executable
		do shell script "chmod +x " & quoted form of launcherScript
		
		-- Open Terminal and run the script
		tell application "Terminal"
			activate
			do script "cd " & quoted form of appDir & " && bash " & quoted form of launcherScript
		end tell
		
	on error errMsg number errCode
		display alert "Error" message errMsg buttons {"OK"} as critical
	end try
end run
