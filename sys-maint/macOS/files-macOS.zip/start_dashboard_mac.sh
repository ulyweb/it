#!/bin/bash
# ============================================================
#  macOS Maintenance Dashboard — Auto Launcher
#  Double-click this file or run: bash start_dashboard_mac.sh
# ============================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAUNCHER="$SCRIPT_DIR/launcher_mac.py"
PORT=9292

clear
echo ""
echo "  ============================================================"
echo "   macOS Maintenance Dashboard  |  Auto-Setup"
echo "  ============================================================"
echo ""

# ── Step 1: Check for Python 3 ───────────────────────────────────────────────
echo "  [1/3] Checking for Python 3..."

PYTHON_BIN=""

# Check python3 first, then python
for candidate in python3 python; do
    if command -v "$candidate" &>/dev/null; then
        VER=$("$candidate" --version 2>&1)
        if [[ "$VER" == *"Python 3"* ]]; then
            PYTHON_BIN="$candidate"
            echo "         Found: $VER"
            break
        fi
    fi
done

# macOS 12.3+ ships without Python by default — try to install via Homebrew or Xcode CLT
if [[ -z "$PYTHON_BIN" ]]; then
    echo "         Python 3 not found. Attempting to install..."
    echo ""

    # Try Homebrew first
    if command -v brew &>/dev/null; then
        echo "         Homebrew found — installing python via brew..."
        brew install python
        if command -v python3 &>/dev/null; then
            PYTHON_BIN="python3"
            echo "         Python 3 installed successfully via Homebrew."
        fi
    fi

    # If still not found, try Xcode Command Line Tools (triggers the install popup)
    if [[ -z "$PYTHON_BIN" ]]; then
        echo "         Trying Xcode Command Line Tools..."
        xcode-select --install 2>/dev/null
        echo ""
        echo "  ┌──────────────────────────────────────────────────────────┐"
        echo "  │  A popup appeared asking to install developer tools.     │"
        echo "  │  Click Install, wait for it to finish, then run this     │"
        echo "  │  script again.                                           │"
        echo "  └──────────────────────────────────────────────────────────┘"
        echo ""
        echo "  Alternatively, install Homebrew first (https://brew.sh):"
        echo "  /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
        echo "  Then run: brew install python3"
        echo ""
        read -p "  Press Enter to exit..."
        exit 1
    fi
fi

echo "  [1/3] Python 3 OK"
echo ""

# ── Step 2: Verify dashboard files ───────────────────────────────────────────
echo "  [2/3] Checking dashboard files..."

if [[ ! -f "$LAUNCHER" ]]; then
    echo "  [ERROR] launcher_mac.py not found in: $SCRIPT_DIR"
    echo "          Make sure all files are in the same folder."
    read -p "  Press Enter to exit..."
    exit 1
fi

if [[ ! -f "$SCRIPT_DIR/dashboard_mac.html" ]]; then
    echo "  [ERROR] dashboard_mac.html not found in: $SCRIPT_DIR"
    read -p "  Press Enter to exit..."
    exit 1
fi

echo "  [2/3] All files present"
echo ""

# ── Step 3: Cache sudo password (avoids hanging mid-command) ─────────────────
echo "  [3/3] Caching sudo credentials for SUDO commands..."
echo "         (Enter your Mac password below — it won't be stored)"
echo ""
sudo -v
if [[ $? -ne 0 ]]; then
    echo "  [WARNING] sudo auth failed or skipped."
    echo "            SUDO commands in the dashboard may not work."
fi
echo ""

# ── Launch ────────────────────────────────────────────────────────────────────
echo "  ============================================================"
echo "   Server  : http://localhost:$PORT"
echo "   Browser : Opening automatically..."
echo "   Stop    : Press Ctrl+C here, or use Shutdown button"
echo "  ============================================================"
echo ""

# Keep sudo alive in the background while server runs
while true; do sudo -n true; sleep 50; done &
SUDO_KEEP=$!

# Trap cleanup
cleanup() {
    kill "$SUDO_KEEP" 2>/dev/null
    echo ""
    echo "  Server stopped."
    exit 0
}
trap cleanup INT TERM

"$PYTHON_BIN" "$LAUNCHER"

kill "$SUDO_KEEP" 2>/dev/null
