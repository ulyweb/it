"""
macOS Maintenance Dashboard - Backend Launcher
Run: python3 launcher_mac.py
Then open: http://localhost:9292
"""

import http.server
import socketserver
import subprocess
import json
import os
import sys
import threading
import webbrowser
import time
import shutil
from urllib.parse import urlparse, parse_qs

PORT = 9292
DASHBOARD_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dashboard_mac.html")

# ── Helpers ───────────────────────────────────────────────────────────────────

def _run(cmd, **kwargs):
    """Run a command, return CompletedProcess. Always text mode."""
    return subprocess.run(cmd, capture_output=True, text=True,
                         errors="replace", **kwargs)

def get_startup_disk():
    """Return the BSD disk name of the current startup volume, e.g. disk3s5."""
    try:
        r = _run(["diskutil", "info", "/"])
        for line in r.stdout.splitlines():
            if "Device Identifier" in line:
                return line.split(":")[-1].strip()  # e.g. disk3s5s1
    except Exception:
        pass
    return "disk0"

def get_container_disk():
    """Return the physical container disk, e.g. disk3 from disk3s5."""
    dev = get_startup_disk()
    # Strip slice suffix — disk3s5s1 → disk3
    parts = dev.replace("disk", "").split("s")
    return f"disk{parts[0]}"

def brew_available():
    return shutil.which("brew") is not None

# ── Command registry ──────────────────────────────────────────────────────────

def build_commands():
    startup = get_startup_disk()
    container = get_container_disk()

    cmds = {
        # ── System Update ──────────────────────────────────────────────────
        "softwareupdate": {
            "name": "macOS Software Update",
            "desc": "softwareupdate -ia",
            "requires_sudo": False,
            "requires_reboot": False,
            "icon": "📦",
            "steps": [
                {"cmd": ["softwareupdate", "--list"], "label": "Checking available updates..."},
                {"cmd": ["softwareupdate", "-ia", "--verbose"], "label": "Installing all available updates..."},
            ]
        },

        # ── Homebrew Update (conditional) ──────────────────────────────────
        "brew_update": {
            "name": "Homebrew Update & Upgrade",
            "desc": "brew update + upgrade",
            "requires_sudo": False,
            "requires_reboot": False,
            "icon": "🍺",
            "steps": [
                {"cmd": ["brew", "update"], "label": "Updating Homebrew formulae..."},
                {"cmd": ["brew", "upgrade"], "label": "Upgrading installed packages..."},
                {"cmd": ["brew", "cleanup", "--prune=7"], "label": "Cleaning up old versions..."},
            ]
        },

        # ── Disk Verify (≈ sfc /scannow) ───────────────────────────────────
        "disk_verify": {
            "name": "Disk Verify (First Aid)",
            "desc": f"diskutil verifyVolume {startup}",
            "requires_sudo": False,
            "requires_reboot": False,
            "icon": "🔍",
            "steps": [
                {"cmd": ["diskutil", "verifyVolume", f"/dev/{startup}"],
                 "label": f"Verifying volume integrity on {startup}..."},
            ]
        },

        # ── Disk Repair (≈ DISM /RestoreHealth) ───────────────────────────
        "disk_repair": {
            "name": "Disk Repair Volume",
            "desc": f"diskutil repairVolume {startup}",
            "requires_sudo": True,
            "requires_reboot": False,
            "icon": "🏥",
            "steps": [
                {"cmd": ["sudo", "diskutil", "repairVolume", f"/dev/{startup}"],
                 "label": f"Repairing volume {startup} (may take a while)..."},
            ]
        },

        # ── Physical Disk Check (≈ chkdsk) ─────────────────────────────────
        "disk_check": {
            "name": "Physical Disk Check (SMART)",
            "desc": f"diskutil verifyDisk {container}",
            "requires_sudo": False,
            "requires_reboot": False,
            "icon": "💾",
            "steps": [
                {"cmd": ["diskutil", "list"], "label": "Listing all disks and partitions..."},
                {"cmd": ["diskutil", "info", container], "label": f"Reading S.M.A.R.T. status for {container}..."},
                {"cmd": ["diskutil", "verifyDisk", container], "label": f"Verifying disk structure on {container}..."},
            ]
        },

        # ── Flush DNS (≈ ipconfig /flushdns) ──────────────────────────────
        "flush_dns": {
            "name": "Flush DNS Cache",
            "desc": "dscacheutil + mDNSResponder",
            "requires_sudo": True,
            "requires_reboot": False,
            "icon": "🔄",
            "steps": [
                {"cmd": ["sudo", "dscacheutil", "-flushcache"],
                 "label": "Flushing DNS cache (dscacheutil)..."},
                {"cmd": ["sudo", "killall", "-HUP", "mDNSResponder"],
                 "label": "Restarting mDNSResponder..."},
                {"cmd": ["sudo", "killall", "-INFO", "mDNSResponder"],
                 "label": "Confirming DNS cache cleared..."},
            ]
        },

        # ── Network Reset (≈ netsh winsock/ip/tcp reset) ───────────────────
        "network_reset": {
            "name": "Network Reset",
            "desc": "Renew DHCP + flush routing",
            "requires_sudo": True,
            "requires_reboot": False,
            "icon": "🔌",
            "steps": [
                # Get default network interface name dynamically
                {"cmd": ["bash", "-c",
                         "route -n get default 2>/dev/null | awk '/interface/{print $2}'"],
                 "label": "Detecting active network interface..."},
                {"cmd": ["bash", "-c",
                         "IFACE=$(route -n get default 2>/dev/null | awk '/interface/{print $2}'); "
                         "echo \"Interface: $IFACE\"; "
                         "sudo ipconfig set $IFACE DHCP && echo 'DHCP lease renewed' || echo 'DHCP renew failed (interface may not use DHCP)'"],
                 "label": "Renewing DHCP lease..."},
                {"cmd": ["sudo", "route", "flush"],
                 "label": "Flushing routing table..."},
                {"cmd": ["sudo", "dscacheutil", "-flushcache"],
                 "label": "Flushing DNS as part of network reset..."},
                {"cmd": ["sudo", "killall", "-HUP", "mDNSResponder"],
                 "label": "Restarting mDNSResponder..."},
                {"cmd": ["networksetup", "-listallhardwareports"],
                 "label": "Listing all network interfaces..."},
            ]
        },

        # ── Disk Health / Physical Info (≈ Get-PhysicalDisk) ──────────────
        "disk_health": {
            "name": "Disk & Storage Health",
            "desc": "system_profiler SPStorageDataType",
            "requires_sudo": False,
            "requires_reboot": False,
            "icon": "🖥️",
            "steps": [
                {"cmd": ["system_profiler", "SPStorageDataType"],
                 "label": "Reading storage device info..."},
                {"cmd": ["diskutil", "info", "-all"],
                 "label": "Reading all disk metadata..."},
                {"cmd": ["bash", "-c", "ioreg -l -n AppleSmartBattery 2>/dev/null | grep -E 'Capacity|Cycle|Health' | head -20 || echo 'No battery detected (desktop Mac)'"],
                 "label": "Reading battery/health data..."},
            ]
        },

        # ── Process List (≈ tasklist) ──────────────────────────────────────
        "proclist": {
            "name": "Process List",
            "desc": "ps aux (all running processes)",
            "requires_sudo": False,
            "requires_reboot": False,
            "icon": "📋",
            "steps": [
                {"cmd": ["ps", "aux", "--sort=-%cpu"],
                 "label": "Listing all running processes (sorted by CPU)..."},
            ]
        },

        # ── Power & Battery Report (≈ powercfg /energy) ───────────────────
        "power_report": {
            "name": "Power & Battery Report",
            "desc": "pmset -g + battery info",
            "requires_sudo": False,
            "requires_reboot": False,
            "icon": "⚡",
            "steps": [
                {"cmd": ["pmset", "-g"],
                 "label": "Reading current power management settings..."},
                {"cmd": ["pmset", "-g", "batt"],
                 "label": "Reading battery status..."},
                {"cmd": ["pmset", "-g", "log"],
                 "label": "Reading recent power events log..."},
                {"cmd": ["bash", "-c",
                         "/usr/libexec/PlistBuddy -c 'Print \"Maximum Capacity Percent\"' "
                         "/dev/stdin <<< $(pmset -g ps -xml) 2>/dev/null "
                         "| xargs -I{} echo 'Battery max capacity: {}%' "
                         "|| echo 'Battery capacity info unavailable (desktop or unsupported)'"],
                 "label": "Reading battery maximum capacity..."},
            ]
        },

        # ── Memory Diagnostics (≈ mdsched) ────────────────────────────────
        "memory_diag": {
            "name": "Memory Diagnostics",
            "desc": "vm_stat + memory_pressure",
            "requires_sudo": False,
            "requires_reboot": False,
            "icon": "🧪",
            "steps": [
                {"cmd": ["vm_stat"],
                 "label": "Reading virtual memory statistics..."},
                {"cmd": ["memory_pressure"],
                 "label": "Reading memory pressure level..."},
                {"cmd": ["bash", "-c", "sysctl hw.memsize hw.physicalcpu hw.logicalcpu"],
                 "label": "Reading hardware memory configuration..."},
                {"cmd": ["bash", "-c",
                         "top -l 1 -s 0 | grep -E 'PhysMem|Swap'"],
                 "label": "Reading physical memory usage summary..."},
            ]
        },

        # ── System Info (bonus — no Windows equivalent, but very useful) ──
        "sys_info": {
            "name": "Full System Info",
            "desc": "sw_vers + system_profiler",
            "requires_sudo": False,
            "requires_reboot": False,
            "icon": "ℹ️",
            "steps": [
                {"cmd": ["sw_vers"],
                 "label": "Reading macOS version..."},
                {"cmd": ["system_profiler", "SPHardwareDataType"],
                 "label": "Reading hardware info (CPU, RAM, serial)..."},
                {"cmd": ["system_profiler", "SPSoftwareDataType"],
                 "label": "Reading software info..."},
                {"cmd": ["uptime"],
                 "label": "Reading system uptime and load averages..."},
            ]
        },
    }

    # Mark brew_update as disabled if Homebrew not installed
    if not brew_available():
        cmds["brew_update"]["disabled"] = True
        cmds["brew_update"]["disabled_reason"] = "Homebrew not installed — visit https://brew.sh"
        cmds["brew_update"]["steps"] = []  # no steps to run
    else:
        cmds["brew_update"]["disabled"] = False

    return cmds

COMMANDS = build_commands()

# ── SSE Output ────────────────────────────────────────────────────────────────

class SSEOutput:
    def __init__(self, wfile):
        self.wfile = wfile

    def send(self, data):
        try:
            msg = f"data: {json.dumps(data)}\n\n"
            self.wfile.write(msg.encode("utf-8"))
            self.wfile.flush()
        except Exception:
            pass

# ── Command runner ────────────────────────────────────────────────────────────

def run_command_stream(cmd_key, sse):
    if cmd_key not in COMMANDS:
        sse.send({"type": "error", "text": f"Unknown command: {cmd_key}"})
        return

    task = COMMANDS[cmd_key]

    # Block disabled commands (e.g. brew_update when Homebrew not installed)
    if task.get("disabled"):
        sse.send({"type": "start", "name": task["name"]})
        sse.send({"type": "error", "text": f"⛔ {task.get('disabled_reason', 'This command is not available.')}"})
        sse.send({"type": "done", "name": task["name"]})
        return

    sse.send({"type": "start", "name": task["name"]})

    if task.get("requires_sudo"):
        sse.send({"type": "info",
                  "text": "⚠ This command uses sudo. If it hangs, run: sudo -v in Terminal first to cache your password."})

    for step in task["steps"]:
        sse.send({"type": "step", "text": step["label"]})
        sse.send({"type": "cmd", "text": " ".join(step["cmd"])})
        try:
            proc = subprocess.Popen(
                step["cmd"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            for line in proc.stdout:
                line = line.rstrip()
                if line:
                    sse.send({"type": "output", "text": line})
            proc.wait()
            rc = proc.returncode
            if rc == 0:
                sse.send({"type": "success", "text": f"✓ Completed (exit {rc})"})
            else:
                sse.send({"type": "warning",
                          "text": f"⚠ Exited with code {rc} — check output above for details."})
        except FileNotFoundError:
            sse.send({"type": "error",
                      "text": f"Command not found: {step['cmd'][0]}. Is it installed?"})
        except Exception as e:
            sse.send({"type": "error", "text": f"Error: {str(e)}"})

    if task.get("requires_reboot"):
        sse.send({"type": "reboot",
                  "text": "⟳ A system restart is recommended to complete this operation."})

    sse.send({"type": "done", "name": task["name"]})


def handle_kill(pid, sse):
    sse.send({"type": "start", "name": f"Kill Process PID {pid}"})
    try:
        result = _run(["kill", "-9", str(pid)])
        out = (result.stdout + result.stderr).strip()
        if out:
            for line in out.splitlines():
                sse.send({"type": "output", "text": line})
        if result.returncode == 0:
            sse.send({"type": "success", "text": f"✓ PID {pid} terminated."})
        else:
            sse.send({"type": "error",
                      "text": f"Failed to kill PID {pid}. Try: sudo kill -9 {pid} in Terminal."})
    except Exception as e:
        sse.send({"type": "error", "text": str(e)})
    sse.send({"type": "done", "name": "kill"})


def get_proc_list():
    """Return process list as a list of dicts."""
    try:
        r = _run(["ps", "axo", "pid,pcpu,pmem,comm"])
        procs = []
        for line in r.stdout.splitlines()[1:]:
            parts = line.split(None, 3)
            if len(parts) == 4:
                procs.append({
                    "pid":  parts[0],
                    "cpu":  parts[1],
                    "mem":  parts[2],
                    "name": os.path.basename(parts[3].strip()),
                })
        return procs
    except Exception:
        return []

# ── HTTP Handler ──────────────────────────────────────────────────────────────

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        parsed = urlparse(self.path)
        path   = parsed.path
        qs     = parse_qs(parsed.query)

        if path in ("/", "/index.html"):
            self.serve_file(DASHBOARD_FILE, "text/html")

        elif path == "/api/commands":
            data = {k: {"name": v["name"], "desc": v["desc"],
                        "icon": v["icon"],
                        "requires_reboot":   v.get("requires_reboot",   False),
                        "requires_sudo":     v.get("requires_sudo",     False),
                        "disabled":          v.get("disabled",          False),
                        "disabled_reason":   v.get("disabled_reason",   "")}
                    for k, v in COMMANDS.items()}
            self.send_json(data)

        elif path == "/api/run":
            cmd_key = qs.get("cmd", [""])[0]
            pid     = qs.get("pid", [""])[0]

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            sse = SSEOutput(self.wfile)
            if pid:
                handle_kill(pid, sse)
            elif cmd_key:
                run_command_stream(cmd_key, sse)
            else:
                sse.send({"type": "error", "text": "No command specified."})

        elif path == "/api/procs":
            self.send_json(get_proc_list())

        elif path == "/api/sysinfo":
            info = {}
            try:
                info["os"]      = _run(["sw_vers", "-productVersion"]).stdout.strip()
                info["build"]   = _run(["sw_vers", "-buildVersion"]).stdout.strip()
                info["model"]   = _run(["sysctl", "-n", "hw.model"]).stdout.strip()
                info["cpu"]     = _run(["sysctl", "-n", "machdep.cpu.brand_string"]).stdout.strip() \
                                  or _run(["sysctl", "-n", "hw.model"]).stdout.strip()
                mem_bytes       = _run(["sysctl", "-n", "hw.memsize"]).stdout.strip()
                info["ram"]     = f"{int(mem_bytes) // (1024**3)} GB" if mem_bytes.isdigit() else "N/A"
                info["uptime"]  = _run(["uptime"]).stdout.strip()
                info["disk"]    = get_startup_disk()
                info["brew"]    = "✓ Installed" if brew_available() else "✗ Not installed"
            except Exception as e:
                info["error"] = str(e)
            self.send_json(info)

        elif path == "/api/shutdown":
            self.send_json({"status": "shutting_down"})
            def _stop():
                time.sleep(0.3)
                print("\n  Shutdown requested from dashboard. Stopping server...")
                self.server.shutdown()
            threading.Thread(target=_stop, daemon=True).start()

        elif path == "/api/status":
            self.send_json({"status": "ok", "port": PORT, "platform": "macOS"})

        else:
            self.send_response(404)
            self.end_headers()

    def serve_file(self, filepath, content_type):
        try:
            with open(filepath, "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", len(content))
            self.end_headers()
            self.wfile.write(content)
        except FileNotFoundError:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"dashboard_mac.html not found")

    def send_json(self, data):
        body = json.dumps(data).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", len(body))
        self.end_headers()
        self.wfile.write(body)


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    try:
        # Pre-flight checks
        disk = get_startup_disk()
        container = get_container_disk()
        brew_ok = brew_available()
        
        print("=" * 55)
        print("  macOS Maintenance Dashboard")
        print("=" * 55)
        print(f"  Server  : http://localhost:{PORT}")
        print(f"  Disk    : {disk} / container {container}")
        print(f"  Homebrew: {'found' if brew_ok else 'not installed'}")
        print("  TIP     : Run 'sudo -v' first to cache sudo password")
        print("  Stop    : Ctrl+C or use Shutdown button in dashboard")
        print("=" * 55)

        with socketserver.TCPServer(("", PORT), Handler) as httpd:
            httpd.allow_reuse_address = True
            threading.Thread(
                target=lambda: (time.sleep(1.2), webbrowser.open(f"http://localhost:{PORT}")),
                daemon=True
            ).start()
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                print("\n  Server stopped.")
                
    except Exception as e:
        print(f"FATAL ERROR: {str(e)}")
        print(f"Type: {type(e).__name__}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
