MAC-MAINT v1.9 - Complete macOS Maintenance Console

This is a self-contained application that includes:
✓ Web-based dashboard (localhost:9292)
✓ Live system telemetry (CPU, Memory, Disk, Uptime)
✓ 20+ maintenance and troubleshooting tools
✓ Enterprise compliance checking
✓ Backup to Box integration
✓ Process monitoring
✓ Security auditing

Everything is included. Just run the app!

Required: Python 3 (usually pre-installed on macOS)

For issues: Check /tmp/mac-maint.log
